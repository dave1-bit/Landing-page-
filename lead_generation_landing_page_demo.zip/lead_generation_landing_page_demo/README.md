# Elevate Studio — Lead Generation Landing Page Demo

A responsive, premium-style lead-generation landing page built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive layout, typography, and styling
- `script.js` — mobile navigation, current year, and demo form validation

## Preview
Open `index.html` in a browser. The page loads Google Fonts when internet access is available; fallback fonts are included.

## Important
The enquiry form demonstrates front-end validation only. It does not send or store submissions. To receive real enquiries, connect it to a form service or your own backend.

## Customize before using as a client demo
- Replace the fictional brand and copy with client-specific content.
- Use original or properly licensed imagery if you add photos.
- Test on multiple screen sizes.
- Connect and test any required form/email integration.
